# Liveright
Liveright is a roommate recommendation system for students seeking accommodation and roommates near their university.

This is the repository that contains data cleaning, exploratory analysis, and recommendation engine of the service. The deployment as a web service is still under development.
