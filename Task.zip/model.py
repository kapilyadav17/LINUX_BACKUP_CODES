# File: model.py

import os
import json
from openai import OpenAI
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

class IntentClassifier:
    def __init__(self):
        self.labels = [
            "Book Appointment",
            "Product Inquiry",
            "Pricing Negotiation",
            "Support Request",
            "Follow-Up"
        ]
        # Use the new OpenAI client
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    def predict(self, conversation: str) -> dict:
        prompt = f"""
You are an AI assistant. Read this WhatsApp-style conversation between a user and a business.

Conversation:
\"\"\"{conversation}\"\"\"

Classify the final intent of the customer. Choose from: {", ".join(self.labels)}.

Also, explain your reasoning in 1 sentence.

Format your response in JSON like this:
{{
  "predicted_intent": "Label from list",
  "rationale": "Why you chose that label"
}}
"""
        # New SDK format
        response = self.client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0
        )

        result = response.choices[0].message.content
        return json.loads(result)  # safer than eval
