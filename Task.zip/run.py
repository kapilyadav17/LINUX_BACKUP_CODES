#run.py is the main launcher script.

import os
from predictor import predict_intents

# Ensure output folder exists
os.makedirs("data/output", exist_ok=True)

if __name__ == "__main__":
    predict_intents(
        input_path="data/input.json",
        output_json="data/output/predictions.json",
        output_csv="data/output/predictions.csv"
    )
