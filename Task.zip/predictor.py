#To run the full prediction pipeline on input JSON and save results.

import json
import csv
from preprocess import format_conversation
from model import IntentClassifier

classifier = IntentClassifier()

def predict_intents(input_path: str, output_json: str, output_csv: str):
    with open(input_path, 'r') as f:
        data = json.load(f)

    results = []

    for convo in data:
        convo_id = convo['conversation_id']
        text = format_conversation(convo['messages'])
        prediction = classifier.predict(text)

        result = {
            "conversation_id": convo_id,
            "predicted_intent": prediction["predicted_intent"],
            "rationale": prediction["rationale"]
        }
        results.append(result)

    with open(output_json, 'w') as f_json:
        json.dump(results, f_json, indent=2)

    with open(output_csv, 'w', newline='') as f_csv:
        writer = csv.DictWriter(f_csv, fieldnames=["conversation_id", "predicted_intent", "rationale"])
        writer.writeheader()
        writer.writerows(results)