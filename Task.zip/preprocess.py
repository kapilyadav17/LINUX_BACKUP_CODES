#TO CLEAN AND PREPROCESS EVERY CHAT BEFORE PASSING IT TO THE MODEL.

import re
from typing import List

def clean_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^\w\s]", "", text)  # remove punctuation
    text = re.sub(r"\s+", " ", text).strip()  # remove extra spaces
    return text

def format_conversation(messages: List[dict], max_turns: int = None) -> str:
    if max_turns:
        messages = messages[-max_turns:]
    return " ".join([f"{msg['sender']}: {clean_text(msg['text'])}" for msg in messages])
