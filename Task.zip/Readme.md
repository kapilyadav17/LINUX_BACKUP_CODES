# Multi-Turn Intent Classification

## 🚀 Project Overview
This project predicts customer intent from WhatsApp-style multi-turn conversations using a zero-shot transformer model.

## 🧠 Model
- facebook/bart-large-mnli (zero-shot)
- Labels: Book Appointment, Product Inquiry, Pricing Negotiation, Support Request, Follow-Up

## 📦 How to Run

1. Install dependencies:
    pip install -r requirements.txt

2. Put input in: `data/input.json`

3. Run:
    python run.py

4. Outputs saved to:
    - data/output/predictions.json
    - data/output/predictions.csv

## 📁 Project Structure
- `src/preprocess.py`: cleans and formats conversations
- `src/model.py`: runs classification
- `src/predictor.py`: handles input/output
- `run.py`: main entry script

## 📌 Notes
- No training needed — uses zero-shot classification.
- Can handle thousands of conversations efficiently.

## 📍 Example Prediction
Input: "Can we do a site visit this week?"  
Prediction: Book Appointment  
Rationale: The user requested a site visit after sharing preferences.

